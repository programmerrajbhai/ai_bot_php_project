<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
    $reply = "তুমি বলেছো: " . $msg;
    echo json_encode(["status" => "success", "reply" => $reply]);
} else {
    echo json_encode(["status" => "error", "reply" => "কোনো মেসেজ পাওয়া যায়নি।"]);
}
